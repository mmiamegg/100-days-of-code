# # class
# class User:
#     # constructor
#     def __init__(self, user_id, username):
#         # class attributes
#         self.id = user_id
#         self.username = username
#         self.followers = 0
#         self.following = 0
#
#     # method
#     def follow(self, user):
#         user.followers += 1
#         self.following += 1
#
#
# # # OBJECT of class User
# # user_1 = User()
#
# # # ATTRIBUTES of class User without constructors
# # user_1.id = "001"
# # user_1.username = "angela"
# # print(user_1.id)
#
# # Passing a value to the class attribute when creating the object
# user_1 = User("001", "angela")
# user_2 = User("002", "jack")
#
# print(user_1.id)
# user_1.follow(user_2)
#
# print(f"User 1 Followers {user_1.followers}")
# print(f"User 1 Following {user_1.following}")
# print(f"User 2 Followers {user_2.followers}")
# print(f"User 2 Following {user_2.following}")

from question_model import Question
from data import question_data
from quiz_brain import QuizBrain

question_bank = []
for question in question_data:
    question_text = question["question"]
    question_answer = question["correct_answer"]
    new_question = Question(question_text, question_answer)
    question_bank.append(new_question)


# print(question_bank[0].answer)
quiz = QuizBrain(question_bank)
while quiz.still_has_questions():
    quiz.next_question()

# if not quiz.still_has_questions():
#     quiz.final_score()
print("You've completed the quiz.")
print(f"Your final score is {quiz.score}/{quiz.question_number}")
