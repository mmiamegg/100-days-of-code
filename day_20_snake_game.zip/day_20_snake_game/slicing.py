# SLICING WORKS ON ARRAYS AND TUPLES

piano_keys = ["a", "b", "c", "d", "e", "f", "g"]


# where before a is 0, before b is 1 etc
# slice from before C to before F
print(piano_keys[2:5])

# print from before C to the last
print(piano_keys[2:])

# print from first to before F
print(piano_keys[:5])

# print from point A to B every other item
print(piano_keys[1:5:2])

# print every other item
print(piano_keys[::2])

# print reverse
print(piano_keys[::-1])
