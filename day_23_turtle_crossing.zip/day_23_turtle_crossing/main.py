import time
from turtle import Screen
from player import Player
from car_manager import CarManager
from scoreboard import Scoreboard

screen = Screen()
screen.setup(width=600, height=600)
screen.bgcolor("black")
screen.tracer(0)

player = Player()
car = CarManager()
scoreboard = Scoreboard()

screen.listen()
screen.onkey(player.move, "Up")

game_is_on = True
while game_is_on:
    time.sleep(0.1)
    screen.update()

    car.create_car()
    car.move_cars()

    for c in car.cars:
        if player.distance(c) < 20:
            scoreboard.game_over()
            game_is_on = False

    # if player.ycor() >= player.finish_line:
    if player.is_at_finish_line():
        player.go_to_start()
        scoreboard.increase_level()
        car.level_up()

screen.exitonclick()

