# from turtle import *
# from turtle import Turtle, Screen
import random
# import turtle

# importing a module with an alias
# import turtle as t
# tim = t.Turtle()

# import heroes
# print(heroes.gen())

# tim = turtle.Turtle()
# tim = t.Turtle()
# t.colormode(255)

# for test in range(15):
#     tim.forward(10)
#     tim.penup()
#     tim.forward(10)
#     tim.pendown()

# sides = 3
# shapes = 8
# color_count = 0
# colors = ["blue", "aquamarine", "chocolate", "blueviolet", "deeppink", "gold", "green", "violet"]

# def random_color():
#     r = random.randint(0, 255)
#     g = random.randint(0, 255)
#     b = random.randint(0, 255)
#     color_tuple = (r, g, b)
#     return color_tuple
#
# while shapes > 1:
#     angle = 360 / sides
#     tim.color(colors[color_count])
#     for side in range(sides):
#         tim.forward(100)
#         tim.right(angle)
#     sides += 1
#     shapes -= 1
#     color_count += 1

# def draw_shape(sides):
#     angle = 360 / sides
#     for side in range(sides):
#         tim.forward(100)
#         tim.right(angle)
#
#
# for shape_side_n in range(3,11):
#     tim.color(random.choice(colors))
#     draw_shape(shape_side_n)

# direction = [0, 90, 180, 270]
# tim.speed(15)
# tim.pensize(10)
#
# for test in range(100):
#     # tim.color(random.choice(colors))
#     tim.color(random_color())
#     tim.forward(25)
#     tim.setheading(random.choice(direction))

# for i in range(72):
#     tilt = 5
#     tim.color(random_color())
#     tim.circle(100)
#     tim.left(tilt)

# MY SOLUTION
# for angle in range(0, 365, 5):
#     tim.color(random_color())
#     tim.circle(100)
#     tim.setheading(angle)

# VIDEO SOLUTION
# def draw_spirograph(size_of_gap):
#     for _ in range(int(360/size_of_gap)):
#         tim.color(random_color())
#         tim.circle(100)
#         tim.setheading(tim.heading() + size_of_gap)

# draw_spirograph(2)

# screen = turtle.Screen()
# screen = t.Screen()
# screen.exitonclick()



# import colorgram

# colors = colorgram.extract('image.jpg', 24)
# rgb_colors = []
#
# for color in colors:
#     # rgb = color.rgb
#     # rgb_list = (rgb.r, rgb.g, rgb.b)
#     r = color.rgb.r
#     g = color.rgb.g
#     b = color.rgb.b
#     rgb_list = (r, g, b)
#     rgb_colors.append(rgb_list)
#
# print(rgb_colors)