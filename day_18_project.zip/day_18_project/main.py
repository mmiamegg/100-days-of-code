import turtle as t
import random

color_list = [(248, 150, 92), (247, 254, 251), (210, 65, 118), (45, 82, 182), (253, 245, 249), (240, 131, 154), (231, 223, 73), (35, 215, 192), (237, 245, 251), (149, 54, 41), (37, 47, 157), (112, 214, 251), (86, 24, 32), (60, 209, 188), (253, 218, 0), (247, 140, 149), (176, 59, 92), (129, 175, 207), (137, 30, 38), (241, 155, 150), (219, 66, 60), (138, 218, 207), (105, 114, 168)]

tim = t.Turtle()
t.colormode(255)
tim.speed(15)
tim.penup()
tim.hideturtle()

for y in range(-210, 290, 50):
    tim.setposition(-225, y)
    for x in range(10):
        tim.dot(20, random.choice(color_list))
        tim.forward(50)

screen = t.Screen()
screen.exitonclick()
