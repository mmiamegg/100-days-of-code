# this example needs to be manually closed
# file = open("C:/Users/limyt/Desktop/new_file.txt")
# contents = file.read()
# print(contents)
# file.close()

with open("../../Desktop/new_file.txt") as file:
    contents = file.read()
    print(contents)

# this example will manage a file and close it after
# mode default is READ ONLY
# "w" is write and will replace all content with new content
# "a" is append
# with open("C:/Users/limyt/Desktop/new_file.txt", mode="a") as file:
#     # contents = file.read()
#     # print(contents)
#     file.write("New text.")