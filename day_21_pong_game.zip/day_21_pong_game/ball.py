from turtle import Turtle

SHAPE = "circle"
COLOR = "white"


class Ball(Turtle):

    def __init__(self):
        super().__init__()
        self.shape(SHAPE)
        self.color(COLOR)
        self.penup()
        self.x_direction = 10
        self.y_direction = 10
        self.move_speed = 0.1

    def reset(self):
        self.x_direction *= -1
        self.move_speed = 0.1
        self.goto(x=0, y=0)

    def move(self):
        new_x = self.xcor() + self.x_direction
        new_y = self.ycor() + self.y_direction
        self.goto(x=new_x, y=new_y)

    def bounce_y(self):
        self.y_direction *= -1
        self.move_speed *= 0.9

    def bounce_x(self):
        self.x_direction *= -1
        self.move_speed *= 0.9






