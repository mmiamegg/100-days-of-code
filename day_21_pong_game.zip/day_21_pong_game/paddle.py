from turtle import Turtle

SHAPE = "square"
PADDLE_WIDTH = 5
PADDLE_HEIGHT = 1


class Paddle(Turtle):

    def __init__(self, position):
        super().__init__()
        self.shape(SHAPE)
        self.shapesize(PADDLE_WIDTH, PADDLE_HEIGHT)
        self.color("white")
        self.penup()
        self.setposition(position)

    def move_up(self):
        new_y = self.ycor() + 20
        self.goto(self.xcor(), new_y)

    def move_down(self):
        new_y = self.ycor() - 20
        self.goto(self.xcor(), new_y)

